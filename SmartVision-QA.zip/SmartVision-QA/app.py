import cv2
import os
import matplotlib.pyplot as plt
import google.generativeai as genai
import speech_recognition as sr
import pyttsx3
import PIL.Image
from flask import Flask, render_template, request, jsonify, redirect, url_for

app = Flask(__name__)

# Initialize text-to-speech engine
engine = pyttsx3.init()

# Initialize speech recognizer
recognizer = sr.Recognizer()

def capture_image():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not open camera")
        return None
    ret, frame = cap.read()
    cap.release()
    if not ret:
        print("Error: Failed to capture image")
        return None
    return frame

def save_image(image, filename):
    if os.path.exists(filename):
        os.remove(filename)
    cv2.imwrite(filename, image)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/configure_api', methods=['POST'])
def configure_api():
    api_key = request.form['api_key']
    os.environ['GOOGLE_API_KEY'] = api_key
    genai.configure(api_key=os.environ['GOOGLE_API_KEY'])
    global model_text, model_vision
    model_text = genai.GenerativeModel('gemini-pro')
    model_vision = genai.GenerativeModel('gemini-pro-vision')
    return redirect(url_for('chat'))

@app.route('/chat')
def chat():
    return render_template('chat.html')

@app.route('/ask_question', methods=['POST'])
def ask_question():
    question = request.form['question']
    response = model_text.generate_content("Think like an AI assistant and answer the question. The question is: " + question)
    return jsonify({'response': response.text})

@app.route('/capture_and_analyze', methods=['POST'])
def capture_and_analyze():
    image = capture_image()
    if image is not None:
        save_image(image, "img1.jpg")
        img = PIL.Image.open('img1.jpg')
        response = model_vision.generate_content(img)
        engine.say(response.text)
        engine.runAndWait()
        return jsonify({'text': response.text})
    else:
        return jsonify({'text': 'Failed to capture image'})

if __name__ == '__main__':
    app.run(debug=True)
