import cv2
import os
import matplotlib.pyplot as plt
import google.generativeai as genai
import speech_recognition as sr
import pyttsx3
import PIL.Image

# Set up API key for GenerativeAI
api_key = "AIzaSyCBN7APuzrPW1x1QCCVQGzmZCx_f7tSyOI"
os.environ['GOOGLE_API_KEY'] = api_key
genai.configure(api_key=os.environ['GOOGLE_API_KEY'])

# Set up GenerativeAI models
model_text = genai.GenerativeModel('gemini-pro')
model_vision = genai.GenerativeModel('gemini-pro-vision')

# Initialize text-to-speech engine
engine = pyttsx3.init()

# Initialize speech recognizer
recognizer = sr.Recognizer()
def capture_image():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not open camera")
        return None
    ret, frame = cap.read()
    cap.release()
    if not ret:
        print("Error: Failed to capture image")
        return None
    return frame

def save_image(image, filename):
    if os.path.exists(filename):
        os.remove(filename)
    cv2.imwrite(filename, image)

def what_is_this():
    image = capture_image()
    if image is not None:
        plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        plt.title("Captured Image")
        plt.axis('off')
        plt.show()
        save_image(image, "img1.jpg")
        img = PIL.Image.open('img1.jpg')
        response = model_vision.generate_content(img)
        engine.say(response.text)
        print(response.text)

while True:
    with sr.Microphone() as source:
        engine.say("Ask me:")
        engine.runAndWait()
        recognizer.adjust_for_ambient_noise(source)
        try:
            audio = recognizer.listen(source, timeout = 2)
            text = recognizer.recognize_google(audio)
            print("You said:", text)
            x = text.lower()
            if 'what' in x and 'is' in x and 'this' in x:
                what_is_this()
            if 'quit' in x:
                break
            response = model_text.generate_content("Think like an AI assistant and answer the question. The question is: " + text)
            print("Model Response:", response.text)
            engine.say(response.text)
            engine.runAndWait()
        except sr.UnknownValueError:
            print("Sorry, I could not understand the audio.")
        except sr.RequestError as e:
            print("Error connecting to the Google Web Speech API: {0}".format(e))